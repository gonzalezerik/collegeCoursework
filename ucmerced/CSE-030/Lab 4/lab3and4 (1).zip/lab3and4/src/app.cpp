#include <iostream>
#include <Arrays.h>

using namespace std;

int main(){
    ResizableArray array;
    
    for (int i = 0; i < 6; i++) {
        array.append(i);
    }
    
    array.insert(2, 77);
    
    array.insert(10, 89);
    
    array.append(101);
    
    // Print out the array
    array.print();

    cout << "count: " << array.counter << endl;
    cout << "size : " << array.size << endl;
    
    return 0;
}
