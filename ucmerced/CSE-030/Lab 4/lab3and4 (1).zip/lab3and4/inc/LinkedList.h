#ifndef LinkedList_h
#define LinkedList_h

#include <iostream>
#include <ostream>

using namespace std;

struct Node{
    int data;
    Node* next;
    
    Node(int value){
        this->data = value;
        this->next = NULL;
    }
};

struct LinkedList {
    Node* head;
    LinkedList(){
    head = NULL;
}

void append(int value){
    if (head == NULL){
        head = new Node(value);
    }

    else{
        Node* newNode = new Node(value);
        Node* temp = head;
        while(temp->next != NULL){
        temp = temp->next;
    }

    temp->next = newNode;
    }
}

void insert(int index, int value) {
    Node* temp = head;
    if(index == 1){
        head = new Node(value);
        head->next = temp;
        return;
    } 
   for(int i=1;i<index-1;i++){
        if(temp->next == NULL){
           Node *newNode = new Node(0);
           temp->next = newNode;
       }
       temp = temp->next;
   }

   Node *newNode = new Node(value);
   newNode->next = temp->next;
   temp->next = newNode;
   }

   int get(int index){
       Node* temp = head;
   while(temp != NULL){
       index--;
       if(index == 0) {
           return temp->data;
       }
       temp = temp->next;
   }

   return -1;

   }

   void set(int index, int value){
   Node* temp = head;
   for(int i=1;i<index;i++){
       if(temp==NULL){
           return;
       }
       temp = temp->next;
   }

   temp->data = value;

   }

void print (){
    Node* temp = head;

    while (temp != NULL) {
        cout << temp->data << " "; 
        temp = temp->next;
   }
   cout << endl;
 }

~LinkedList(){
    Node* temp = head;
    while(temp != NULL){
        temp = temp->next;
        delete head;
        head = temp;
        }
    }
};


#endif