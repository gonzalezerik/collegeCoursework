#include <stdio.h>

int sum(int x, int y);
int main(){

    int m = 10;
    int n = 5;

    printf("%d\n", sum(m,n));   

    return 0;
}
int sum(int x, int y){
    int sum = x + y;
    return sum;
}