#include<stdio.h>

int bar(int a, int b, int c) {
    printf("\nBar:");
    int d = c - a;
    printf("\nD %d", d);
    return d << b;

    return c - a << 5;
}

int foo(int m, int n, int o) {
    int p = bar(m + n, n + o, o + m);
    printf("\n\nP: %d", &p);
    int q = bar(m - o, n - m, 2 * n);
    printf("\n\nQ: %d", &q);
    printf("\nP+Q: ", (p + q));
    return p + q;
}

int main() { 
    int x = 5, y = 10, z = 15;
    z = x + y + z + foo(x, y, z);
    printf("\nZ: %d", &z);
    printf("%d\n", z);
    return 0;
}
