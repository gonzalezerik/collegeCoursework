#include <stdio.h>

struct position {
    int x, y;
};

struct position findCoords(int x, int y){
    struct position pos;
    pos.x = 0;
    pos.y = 0; 
}














/*
int down(char** arr, char* word, int x, int y, int z){
    
}

int up(char** arr, char* word, int x, int y, int z){
    
}

int left(char** arr, char* word, int x, int y, int z){
    
}
int right(char** arr, char* word, int x, int y, int z){
    
}

int DownDiagonalLeft(char** arr, char* word, int x, int y, int z){
    
}

int DownDiagonalRight(){
    
}

int UpDiagonalLeft(){
    
}

int UpDiagonalRight(){
    
}*/