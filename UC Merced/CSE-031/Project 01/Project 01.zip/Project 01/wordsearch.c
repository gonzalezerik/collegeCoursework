#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "header.h"


// Declarations of the two functions you will implement
// Feel free to declare any helper functions or global variables
void printPuzzle(char** arr);
void searchPuzzle(char** arr, char* word);
void letterArr(char* word);
void letterCheck(char* word);
void checkAround(char** arr, char* word, int x, int y, int i);


int bSize;

// Main function, DO NOT MODIFY 	
int main(int argc, char **argv) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <puzzle file name>\n", argv[0]);
        return 2;
    }
    int i, j;
    FILE *fptr;

    // Open file for reading puzzle
    fptr = fopen(argv[1], "r");
    if (fptr == NULL) {
        printf("Cannot Open Puzzle File!\n");
        return 0;
    }

    // Read the size of the puzzle block
    fscanf(fptr, "%d\n", &bSize);
    
    // Allocate space for the puzzle block and the word to be searched
    char **block = (char**)malloc(bSize * sizeof(char*));
    char *word = (char*)malloc(20 * sizeof(char));

    // Read puzzle block into 2D arrays
    for(i = 0; i < bSize; i++) {
        *(block + i) = (char*)malloc(bSize * sizeof(char));
        for (j = 0; j < bSize - 1; ++j) {
            fscanf(fptr, "%c ", *(block + i) + j);            
        }
        fscanf(fptr, "%c \n", *(block + i) + j);
    }
    fclose(fptr);

    printf("Enter the word to search: ");
    scanf("%s", word);
    
    // Print out original puzzle grid
    printf("\nPrinting puzzle before search:\n");
    printPuzzle(block);
    
    // Call searchPuzzle to the word in the puzzle
    searchPuzzle(block, word);
    
    return 0;
}

void printPuzzle(char** arr) {
	// This function will print out the complete puzzle grid (arr). It must produce the output in the SAME format as the samples in the instructions.
    // Your implementation here...
    for(int i = 0; i< bSize; i++){
		for(int j = 0; j < bSize; j++){
			printf("%c ", *(*(arr + i) + j));
		}
		printf("\n");
	}
}

void searchPuzzle(char** arr, char* word) {
    // This function checks if arr contains the search word. If the word appears in arr, it will print out a message and the path as shown in 
    // the sample runs. If not found, it will print a different message as shown in the sample runs.
    // Your implementation here...
     int wordLen = (strlen(word));
    
    char *extraCoords = (char*)malloc(bSize * sizeof(char));

    for(int i = 0; i < wordLen; i++){
        LtoU(word);
        //printf("\nWord: %s", word);

    }

    int size = 0;
    for (int i = 0; i < bSize; i++){
        //printf("\n%c", *(word + i) );
        size++;
    }
    
    int matchCount = 0;
    printf("\nFinding the first letter match");
    int k = 0;
    int i = 0;
    int j = 0;
    struct position pos;
    int count = 0;
    while(k != 1){
        for( i = 0; i < bSize; i++){
            for( j = 0; j < bSize; j++){
                if( *(*(arr + i) + j) == *(word + k) ){
                    printf("\nFound %c at coords: %d, %d", *(word + k), i, j);
                    matchCount++;
                    if (matchCount == 1){
                        printf("\n %d, %d", i , j);
                        pos.x = i;
                        pos.y = j;
                    }
                    if(matchCount > 1){
                        printf("\n %d, %d", i , j);
                        *(extraCoords + count) = i;
                        *(extraCoords + count + 1) = j;
                        count += 1;
                        }
                    } 
                }
            }
            k++;
        }
    for(int i = 0; i < (matchCount - 1); i++){
        printf("\nSaved extra coords: %d, %d", *(extraCoords + i), *(extraCoords + i + 1) );
    }

    printf("\nStarting at position %d, %d", pos.x, pos.y);

    

    printf("\nSearching for word: %s", word);
    checkAround(arr, word, pos.x, pos.y, i);
    for(int i = 0; i< bSize; i++){
		*(arr+i) = (char *)malloc(bSize*sizeof(char *));
		for(int j = 0; j < bSize; j++){
			*(*(arr+i)+j) = 0;
		}
	}

    for(int i = 0; i< bSize; i++){
		for(int j = 0; j < bSize; j++){
			printf("%d ",*(*(arr+i)+j));
		}
		printf("\n");
	}
}
void LtoU (char *word){
    char* newWord = word;
    while(*newWord){
        if('a' <= *newWord || *newWord >= 'z') *newWord -= 32;
        newWord++;
    }
}


void checkAround(char** arr, char* word, int x, int y, int i){
    int count = 0;
    int *directionsArr;

    for(int i = 0; i < 8; i++){
        switch(i){
            case 0:
            /*
                printf("\nChecking Down");
                printf("\nLetter: %c", *(word + i));
                printf("\nLetter Below: %c", ( *(*(arr + x + 1) + y)));
                printf("\nNext Letter after %c: %c",*(word + i), *(word + i + 1)); */
                if(x == 4){
                    printf("\nYou can't go down");
                } else{
                    if(( *(*(arr + x + 1) + y)) == *(word + i + 1)){
                    printf("\nYou can go down");
                    count++;
                    *(directionsArr + i) = 0;
                } else{
                    printf("\nYou cant go down");
                }

                }

            
                break;
            case 1:

                if (x == 0){
                    printf("\nYou can't go up");
                } else{
                    if(( *(*(arr + x - 1) + y)) == *(word + i)){
                        printf("\nYou can go Up");
                        count++;
                        *(directionsArr + i) = 1;
                } else{
                    printf("\nYou cant go Up");
                }

                }
            
                break;
            case 2:
                if(y == 0){
                    printf("\nYou can't go Left");
                } else{
                    if(( *(*(arr + x) + y - 1)) == *(word + i - 1)){
                    printf("\nYou can go Left");
                    count++;
                    *(directionsArr + i) = 2;
                } else{
                    printf("\nYou cant go Left");
                }
                    
                }

                break;
            case 3:
                if(y == 4){
                    printf("\nYou can't go Right");
                } else{
                    if(( *(*(arr + x) + y + 1)) == *(word + i - 2)){
                    printf("\nYou can go Right");
                    count++;
                    *(directionsArr + i) = 3;
                } else{
                    printf("\nYou cant go Right");
                }
                    
                }

                 break;
            case 4:
            /*
                printf("\n\n\nChecking Down Diagonal Left");
                printf("\nLetter: %c", *(word + i - 4));
                printf("\nLetter Diagonally below to the left: %c", ( *(*(arr + x + 1) + y - 1)));
                printf("\nNext Letter after %c: %c",*(word + i + 1), *(word + i + 1)); */
                //printf("\nLetter Diagonally below to the left: %c", ( *(*(arr + x + 1) + y - 1)));
                
                //printf("\nNext Letter after %c: %c",*(word + i - 4), *(word + i - 3));

                if(y == 0){
                    printf("\nYou can't go Down Diagonally left");
                } else{
                    if(( *(*(arr + x + 1) + y - 1)) == *(word + i - 3)){
                    printf("\nYou can go Down DDiagonally Down left");
                    count++;
                    *(directionsArr + i) = 4;
                } else{
                    printf("\nYou cant go Down Diagonally left");
                }
                    
                }


                
                
                
                break;
            case 5:
            /*
                printf("\n\n\n\nChecking Down Diagonal Right");
                printf("\nLetter: %c", *(word + i - 5));
                printf("\nLetter Diagonally below to the Right: %c", ( *(*(arr + x - 1) + y - 1)));
                printf("\nNext Letter after %c: %c",*(word + i - 5), *(word + i - 4)); */
                //printf("\nLetter Diagonally below to the Right: %c", ( *(*(arr + x + 1) + y + 1)));
                //printf("\nNext Letter after %c: %c",*(word + i - 5), *(word + i - 4));

                if(y == 4){
                    printf("\nYou can't go Down Diagonally Right");
                } else{
                    if(( *(*(arr + x + 1) + y + 1)) == *(word + i - 4)){
                    printf("\nYou can go Down Diagonally Down Right");
                    count++;
                    *(directionsArr + i) = 5;
                } else{
                    printf("\nYou cant go Down Diagonally Right");
                }
                    
                }

                
               
                break;
            case 6:
            /*
                printf("\n\n\n\nChecking Up Diagonal Right");
                printf("\nLetter: %c", *(word + i - 6));
                printf("\nLetter Diagonally above to the Right: %c", ( *(*(arr + x - 1) + y + 1)));
                printf("\nNext Letter after %c: %c",*(word + i - 6), *(word + i - 5));
                */
              // printf("\nLetter Diagonally above to the Right: %c", ( *(*(arr + x - 1) + y + 1)));

               if (x == 0){
                    printf("\nYou can't go up Diagonally to the right");
                } else{
                    if(( *(*(arr + x - 1) + y + 1)) == *(word + i - 5)){
                        printf("\nYou can go Up Diagonally to the right");
                        count++;
                        *(directionsArr + i) = 6;
                } else{
                    printf("\nYou cant go Up Diagonally to the right");
                }

                }
                
                break;
            case 7:
            /*
                printf("\nChecking Up Diagonal Left");
                printf("\nLetter: %c", *(word + i - 7));
                printf("\nLetter Diagonally above to the Left: %c", ( *(*(arr + x + 1) + y + 1)));
                printf("\nNext Letter after %c: %c",*(word + i - 7), *(word + i - 6));
                */
               //printf("\nLetter Diagonally above to the Left: %c", ( *(*(arr + x - 1) + y - 1)));

               if (x == 0){
                    printf("\nYou can't go up Diagonally to the left");
                } else{
                    if(( *(*(arr + x - 1) + y - 1)) == *(word + i - 5)){
                        printf("\nYou can go Up Diagonally to the left");
                        count++;
                        *(directionsArr + i) = 7;
                } else{
                    printf("\nYou cant go Up Diagonally to the left");
                }

                }

              
                break;
        }
    }
    printf("\nYou can go in %d directions!\n", count);

    return *directionsArr;
}
 /*
    }
    if(x == bSize - (bSize - 1)){
        printf("\nYou can't go up!");
    } else {
        if(( *(*(arr + x) + y) == ( *(*(arr + x - 1) + y) ))){
        printf("\nYou can go Up");
    }
    else{
        printf("\nYou can't go Up!");2
    }
    } */


    /*
    if(( *(*(arr + x) + y) == ( *(*(arr + x ) + y + 1) ))){
        printf("\nYou can go right");
    }
    else{
        printf("You can't go right!");
    }

    if(( *(*(arr + x) + y) == ( *(*(arr + x ) + y - 1) ))){
        printf("\nYou can go left");
    }
    else{
        printf("You can't go left!");
    }
*/



/*
    while (count != 7){
       switch (count){
           //Down
            case 0:
                if(x == bSize - 1){
                    printf("\nYou can't go Down");
                }
                if(( *(*(arr + x) + y) == ( *(*(arr + x + 1) + y) ))){
                    printf("\nYou can go Down");
                }

            //Up
            case 1:
            if(x == bSize - (bSize- 1)){
                printf("\nCan't go Down");
            } else{
                  if(( *(*(arr + x) + y) == ( *(*(arr + x - 1) + y) ))){
                    printf("\nYou can go Up");
                }
            }
          
            //Right
            case 2:
            if(y == bSize - 1){
                printf("Can't go right");
            } else{
                  if(( *(*(arr + x) + y) == ( *(*(arr + x) + (y - 1)) ))){
                    printf("You can go right");
                }
            }
            
            //Left
            case 3:
            if(x == bSize - (bSize - 1)){
                printf("Can't go left");
            } else{
                  if(( *(*(arr + x) + y) == ( *(*(arr + x) + (y - 1)) ))){
                    printf("You can go left");
                }
            }
              

        }
        count++;
    }*/

    //Down
    //printf("\nX: %d", x);


    /*
    //Up
    if (x == 0){
        printf("\nCan't go up");
    } else {
        if( *(*(arr + x - 1) + y) == *(word + z + 1) ){
            printf("\nCan go up");
            j++;
        }
    }
  
    //Left
    if( *(*(arr + x) + y - 1) == *(word + z + 1) ){
        printf("\nCan go Left");
        j++;
    }
    //Right
    if (x == 0){
        printf("\nCan't go Right");
    } else{
        if( *(*(arr + x) + y + 1) == *(word + z + 1) ){
            printf("\nCan go Right");
            j++;
        }
    }*/




void letterCheck(char* word){
    printf("\n%s", word);

    
}

int TopLBotR(char** arr){
    bool tOrf;


    return tOrf;
}

int DiaTopRBotL(){
    bool tOrf;

    return tOrf;
}

int RightLeft(char** arr, char* word){
    bool tOrf;

    printf("\nMoving Right to left:");
        for(int i = 0; i < bSize; i++){
            for(int j = 0; j < bSize; j++){
                if(*(*(arr + i) + j) == *(word + i) ) {
                    printf("\nFound letter at %x, %x", j, i);
                }
         }   
    }


    return tOrf;
} 

int LeftRight(){
    bool tOrf;



    return tOrf;
}

int UpDown(){
    bool tOrf;

    return tOrf;
}


/* 


   for(int i = 0; i< bSize; i++){
		*(arr+i) = (char *)malloc(bSize*sizeof(char *));
		for(int j = 0; j < bSize; j++){
			*(*(arr+i)+j) = 0;
		}
	}

    for(int i = 0; i< bSize; i++){
		for(int j = 0; j < bSize; j++){
			printf("%d ",*(*(arr+i)+j));
		}
		printf("\n");
	} */

    
    /*
    int i = 0;
    while (i < bSize){
        switch (i){
            case 0:
                TopLBotR();
                if (TopLBotR == true){

                }
            case 1:
                DiaTopRBotL();
                if (TopLBotR == false){

                }
            case 2:
                RightLeft();
                if(RightLeft == true){

                }
            case 3:
                LeftRight();
                if (LeftRight == true){

                }
            case 4:
                UpDown();
                if (UpDown == true){

                }
        }

    }*/