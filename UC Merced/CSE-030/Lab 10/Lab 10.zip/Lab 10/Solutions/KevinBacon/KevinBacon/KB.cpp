#include <iostream>
#include <string>
#include <vector>
#include <deque>

using namespace std;

struct Edge {
    string label;
    string vertex;
    
    Edge(string label, string vertex){
        this->label = label;
        this->vertex = vertex;
    }
};

struct Pair{
    string vertex;
    string edge;
    
    Pair(string v, string e){
        vertex = v;
        edge = e;
    }
};

struct Triple {
    string vertex;
    string parent;
    string edge;
    
    Triple(string v, string p, string e){
        vertex = v;
        parent = p;
        edge = e;
    }
};

struct Vertex {
    string label;
    std::vector<Edge*> adjList;
    
    Vertex(string label){
        this->label = label;
    }
};

struct Graph {
    std::vector<Vertex*> vertices;
    Graph(){
        
    }
    
    void vertexInsert(string val){
        Vertex* v = new Vertex(val);
        vertices.push_back(v);
    }
    
    void edgeInsert(string label, string from, string to){
        int src = 0;
        int dst = 0;
        for (int i = 0; i < vertices.size(); i++){
            if (vertices[i]->label == from){
                src = i;
            }
            if (vertices[i]->label == to){
                dst = i;
            }
        }
        
        vertices[src]->adjList.push_back(new Edge(label, to));
        vertices[dst]->adjList.push_back(new Edge(label, from));
    }
    
    void print (){
        for (int i = 0; i < vertices.size(); i++){
            std::cout << vertices[i]->label << ": ";
            for (int j = 0; j < vertices[i]->adjList.size(); j++){
                std::cout << vertices[i]->adjList[j]->label << " - " << vertices[i]->adjList[j]->vertex << ", ";
            }
            std::cout << std::endl;
        }
        
    }
    
    bool contains(std::vector<string> somelist, string value){
        for (int i = 0; i < somelist.size(); i++){
            if (somelist[i] == value){
                return true;
            }
        }
        return false;
    }
    
    bool chain (string start, string destination){
        std::deque<string> q;
        std::vector<string> seen;
        std::vector<Triple*> parent;
        std::deque<Pair*> path;

        q.push_back(start);
        parent.push_back(new Triple(start, "none", "none"));

        while(!q.empty()){
            string curr = q.at(0);
            q.pop_front();
            seen.push_back(curr);
            
//            std::cout << "Examining " << curr << std::endl;
            if (curr == destination){
                string x = curr;
                while (x != start){
                    int k = 0;
                    for(; k < parent.size(); k++){
                        if (parent[k]->vertex == x){
                            break;
                        }
                    }
                    
                    path.push_front(new Pair(parent[k]->parent, parent[k]->edge));
                    x = parent[k]->parent;
                    
                }
                
                
                
                for (int i = 0; i < path.size(); i++){
                    cout << path[i]->vertex << " (" << path[i]->edge << ") " ;
                }
                cout << destination << endl;
                return true;
            }
            
            int temp = 0;
            
            for (; temp < vertices.size(); temp++){
                if (vertices[temp]->label == curr) break;
            }

            Vertex* v = vertices[temp];

            for (int i = 0; i < v->adjList.size(); i++){
                if (!contains(seen, v->adjList[i]->vertex)){
                    q.push_back(v->adjList[i]->vertex);
                    seen.push_back(v->adjList[i]->vertex);
                    parent.push_back(new Triple(v->adjList[i]->vertex, v->label, v->adjList[i]->label));
                }
            }

        }
        cout << start << " is not connected to " << destination << endl;
        return false;
    }
    
    
};

int main(int argc, const char * argv[]) {
    
    // The graph that stores the movie database
    Graph imdb;
    
    
    // Each actor is a vertex
    imdb.vertexInsert("Al Pacino");
    imdb.vertexInsert("Robert De Niro");
    imdb.vertexInsert("Marlon Brando");
    imdb.vertexInsert("Mark Hamill");
    imdb.vertexInsert("Harrison Ford");
    imdb.vertexInsert("Sean Connery");
    imdb.vertexInsert("Kevin Costner");
    imdb.vertexInsert("John Cena");
    
    // If two actors have been in a movie together,
    // they are connected by an edge
    // The edge is labelled witht the name of the movie
    
    imdb.edgeInsert("The Godfather", "Al Pacino", "Marlon Brando");
    imdb.edgeInsert("Heat", "Al Pacino", "Robert De Niro");
    
    imdb.edgeInsert("Star Wars", "Mark Hamill", "Harrison Ford");
    imdb.edgeInsert("Indiana Jones", "Harrison Ford", "Sean Connery");
    imdb.edgeInsert("The Untouchables", "Sean Connery", "Kevin Costner");
    imdb.edgeInsert("The Untouchables", "Robert De Niro", "Kevin Costner");
    imdb.edgeInsert("The Untouchables", "Robert De Niro", "Sean Connery");
    
    
    imdb.chain("Marlon Brando", "Robert De Niro");
    imdb.chain("Sean Connery", "Harrison Ford");
    imdb.chain("Kevin Costner", "Al Pacino");
    imdb.chain("Mark Hamill", "John Cena");

//    Expected output:
//
//    Marlon Brando (The Godfather) Al Pacino (Heat) Robert De Niro
//    Sean Connery (Indiana Jones) Harrison Ford
//    Kevin Costner (The Untouchables) Robert De Niro (Heat) Al Pacino
//    Mark Hamill is not connected to John Cena
    
    return 0;
}
