#include <igloo/igloo.h>
#include <MemoryStuff.h>

using namespace igloo;

Context(DecimalToHexTest){
	//Yes I think they are enough and not more cases are needed because it checks numbers that have no letters in the hexademical value and also checks the numbers that have letters in the hexademical value and that they are also in the right place
	Spec(Seven_07){
		// Check to see if we actually add a 0 in front of a single digit result
		Assert::That(decToHex(7), Equals("07"));
	}

	Spec(Fifteen_0F){
		// Check to see if hex symbols A-F are in upper case
		Assert::That(decToHex(15), Equals("0F"));
	}
};

Context(MemoryContentFunctionTest){
	Spec(ThreeHundredFourteen_00_00_01_3A){
		Assert::That(memoryContents(314), Equals("3A:01:00:00")); 
	}
	
	// Your code here
	Spec(TwoThousandTwenty_What){
		Assert::That(memoryContents(2020), Equals("E4:07:00:00")); 
		
	}

	Spec(TwentyEight_What){
		Assert::That(memoryContents(28), Equals("1C:00:00:00")); 
		
	}

	Spec(One_What){
		Assert::That(memoryContents(1), Equals("01:00:00:00")); 
		
	}


};

int main() {
	// Run all the tests defined above
	return TestRunner::RunAllTests();
}
