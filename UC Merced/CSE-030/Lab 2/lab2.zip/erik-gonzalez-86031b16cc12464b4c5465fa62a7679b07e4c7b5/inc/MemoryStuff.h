#ifndef MemoryStuff_h
#define MemoryStuff_h

#include <string>
#include <sstream>
using namespace std;
// A helper function to convert an integer (decimal value)
// to a hexadecimal representaion saved as a string
std::string decToHex(int x){
	std::stringstream ss;
	ss << std::hex << x;
	std::string res ( ss.str() );

	// Convert the result to upper case so hex values look better
	for (int i = 0; i< res.length(); ++i){
		res[i] = std::toupper(res[i]);
	}
    	
	// If the result is only one digit, add a zero to the front
	// Example: the number 10 in hexadecimal is A
	// so this function will return 0A, which is the same thing
    if (res.size() == 1){
        res = "0" + res;
    }

	return res;
}

std::string memoryContents(int x){
	// Your code here

	int* p = &x;

    unsigned char* c;

    string str1;
    string str2;
    string str3;
    string str4;
    string final;


    c = (unsigned char*)p;
    str1 = decToHex(*c);

    c = (unsigned char*)p+1;
    str2 = decToHex(*c);

    c = (unsigned char*)p+2;
    str3 = decToHex(*c);

    c = (unsigned char*)p+3;
    str4 = decToHex(*c);
    
    final.append(str1);
    final.append(":");
    final.append(str2);
    final.append(":");
    final.append(str3);
    final.append(":");
    final.append(str4);

    cout << final << endl;

    return final; 
	// The return value above is just a placeholder.
	// Make the function return the appropriate string value.
}

#endif
