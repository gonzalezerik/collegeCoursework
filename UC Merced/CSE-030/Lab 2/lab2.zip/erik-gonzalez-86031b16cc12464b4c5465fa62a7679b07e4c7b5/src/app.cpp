#include <iostream>
#include <MemoryStuff.h>

using namespace std;

int main(){
    int x;
    cout << "Enter an integer: ";
    cin >> x;

    cout << memoryContents(x) << endl;
    
    
    return 0;
}
