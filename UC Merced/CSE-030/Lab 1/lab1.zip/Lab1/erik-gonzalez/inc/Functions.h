#ifndef Functions_h
#define Functions_h 

using namespace std;

int max(int x, int y) {
	if (x > y){
		return x;
	}
	else {
		return y;
	}
}

int even (int num){
	if (num % 2 == 0){
		return true;
	} else{
		return false;
	}

}

int sum (int num){
	int result = 0;

	for (int i = 0; i <= num; i++){
		if (i % 2 == 0){
			result += i;
		}
	}

	return result;
}

#endif
