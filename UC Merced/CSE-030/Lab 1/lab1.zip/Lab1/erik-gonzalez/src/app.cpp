#include <iostream>
#include </home/erik/CSE30/Labs/Lab1/erik-gonzalez/inc/Functions.h>

using namespace std;

int main(){
    if (even(0) == false){
        cout << "The number 0 is odd" << endl;
    }
    else{
        cout << "The number 0 is odd" << endl;
    }

    cout << "The sum of even numbers up to and including 100 is: " << sum(100) << endl;
    return 0;
}
