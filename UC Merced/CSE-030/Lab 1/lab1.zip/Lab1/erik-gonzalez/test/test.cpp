#include </home/erik/CSE30/Labs/Lab1/erik-gonzalez/dep/igloo/igloo.h>
#include </home/erik/CSE30/Labs/Lab1/erik-gonzalez/inc/Functions.h>

using namespace igloo;


Context(MaxFunctionTests){
	Spec(OneGreatherThanZero){
		Assert::That(max(1,0), Equals(1));
		}
	Spec(ZeroLessThanOne){
		Assert::That(max(0,1), Equals(1));
	}
	Spec(FiveGreatherThanTwo){
		Assert::That(max(5,2), Equals(5));
	}
	Spec(SevenLessThanNine){
		Assert::That(max(7,9), Equals (9));
	}
};

Context(EvenFunctionTests){
	Spec(IsTwentyTwoEven){
		Assert::That(even(22), Equals(true));
	}
	
	Spec(IsThirtyThreeEven){
		Assert::That(even(33), Equals(false));
	}

	Spec(IsTenEven){
		Assert::That(even(10), Equals(true));
	}
};

Context(PostiveNumSum){
	Spec(AddUp10){
		Assert::That(sum(10), Equals(30));
	}

	Spec(AddUp20){
		Assert::That(sum(20), Equals(110));
	}

	Spec(AddUp30){
		Assert::That(sum(30), Equals(240));
	}
};

int main() {
	// Run all the tests defined above
	return TestRunner::RunAllTests();
}
