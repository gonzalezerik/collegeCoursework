#include <iostream>
#include <fstream>
#include <algorithm>
#include <string>
#include <Array.h>
#include <LinkedList.h>
#include <TimeSupport.h>
#include <RandomSupport.h>
#include <BST.h>


using namespace std;

string reverse(string word){
    reverse(word.begin(), word.end());
    return word;
}

bool find(string word, ResizableArray& arr){
    for (long i = 0; i < arr.count; i++){
        if (word == arr[i]){
            return true;
        }
    }
    return false;
}

int main(){

    fstream file;

    ResizableArray words;

    file.open("words.txt",ios::in);
    if (file.is_open()){
        string tp;
        while(getline(file, tp)){
            words.append(tp);  
        }
        file.close(); 
    }
    else{
        cout << "Could not read file..." << endl;
    }

    int count = 0;
    for (long i = 0; i < words.count; i++){
        // if (reverse(words[i]) ==  words[i]){
        string rev = reverse(words[i]);
        if (find(rev, words)){
            //cout << words[i] << endl;
            count++;
        }
    }

    cout << "There were " << count << " words that match..." << endl;

    return 0;
}




















